# AI Assistant 模块（`/mz/ai/`）

Mazmot 自带的轻量 AI 助手封装库，位于仓库 `/mz/ai/` 目录，统一封装 DeepSeek、Kimi、GLM 提供商，提供 API Key 管理、对话、思考模式、流式输出、请求取消等能力。

> **应用侧快速上手**：如果你的应用只需要调用 AI 对话能力，**基本不用关心 key 管理 API**（`saveKey` / `removeKey` / `setKeyDisabled` / `getApiKeys` / `onApiKeysChange` / `testApiKey`）——那些是 AI Key 管理器应用自己用的。应用侧只需用 `getAssistant()` 拿到 Assistant 实例，然后调 `chat()` / `getModels()` / `getRemaining()` 即可：

```js
import { getAssistant } from "/mz/ai/main.js";

// 拿到 Assistant 实例（host 端已配置好 key）
const assistant = getAssistant();
const { content } = await assistant.chat({
  messages: [{ role: "user", content: "你好" }],
});
```

> **妙造隔离预览**：预览容器没有 key 配置，receiver 注入的 import map 会把 `/mz/ai/main.js` 顶替为 `bridge/guest/mz-ai.js` 替身——`getAssistant()` 导出面同形（`providerName` 为 `"bridge"`），chat/getModels 经能力桥转发妙造主容器用自己的 key/模型执行（**model / 推理档位不开放预览应用指定**，统一用妙造主界面当前选中项）；key 管理 API 在预览域抛可读错误、`getApiKeys()` 返回空数组。应用代码零感知；改真模块应用侧用法时必须同步替身（见 `official-apps/conjure/CONTEXT.md`「预览能力桥」）。

下面先讲应用侧常用的 Assistant API，再附上完整的 key 管理 API（给 AI Key 管理器或代理服务用）。

> 需要在对话中让模型自动调用工具（Agent 循环）、会话记忆等，请查 [ai-chain.md](./ai-chain.md)（`/mz/ai/chain/`）。

## 应用侧常用 API

由 `getAssistant()` / `new DeepseekAssistant(id, apiKey)` / `new KimiAssistant(id, apiKey)` / `new GlmAssistant(id, apiKey)` / `new GlmCodingAssistant(id, apiKey)` / `new OpenAIAssistant(id, apiKey)` / `new GeminiAssistant(id, apiKey)` / `new AnthropicAssistant(id, apiKey)` / `new RelayAssistant(id, inviteCode)` 获得。基类 `Assistant` 位于 `/mz/ai/supplier/assistant.js`；国内厂商子类在 `deepseek.js` / `kimi.js` / `glm.js` / `relay.js`，openai-compat 家族（openai / gemini / anthropic / qwen）共用 `openai-compat.js` 基类（OpenAI 兼容 wire，模型清单动态拉取并过滤非对话模型，无余额接口返回空 balances，Anthropic 附加 `x-api-key` + `anthropic-version` 头且不透传思考档位，Qwen 思考走 `enable_thinking` 开关）。

### assistant.providerName

只读属性，标识该实例来自哪个提供商，取值为全小写字符串 `"deepseek"` / `"kimi"` / `"glm"` / `"glm-coding"` / `"openai"` / `"gemini"` / `"anthropic"` / `"qwen"` / `"relay"`（与 key 对象的 `provider` 一致）。当用 `getAssistant()` 随机取实例、又想知道拿到的是哪家时可读取它：

```js
const assistant = getAssistant();
console.log(assistant.providerName); // "deepseek" / "kimi" / "glm" / "glm-coding" / "openai" / "gemini" / "anthropic" / "qwen" / "relay"
```

### chat(options)

```js
const response = await assistant.chat({
  messages: [
    { role: "system", content: "You are a helpful assistant." },
    { role: "user", content: "你好" },
  ],
  thinking: false,
  stream: false,
  model: "deepseek-flash",
  onStream: (data) => { /* ... */ },
  signal: controller.signal, // AbortSignal
});
```

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `messages` | array | - | 消息数组，含 role/content |
| `thinking` | boolean | false | 是否启用思考模式（DeepSeek / GLM / Kimi k2.6 / k2.5 生效；GLM-5.3+ 思考不可关闭，仅影响默认档位） |
| `stream` | boolean | false | 是否启用流式输出 |
| `model` | string | - | 模型名称 |
| `onStream` | function | null | 流式输出回调 |
| `reasoningEffort` | string | "low" | 推理强度。DeepSeek：`low`/`high`/`max`（官方另接受 `minimal`/`medium`/`xhigh`/`ultra` 并自动映射三档）；kimi-k3：`low`/`high`/`max`；GLM-5.3+：`low`/`high`/`max`（见「思考模式 → GLM」） |
| `thinkingKeep` | string | null | 仅 `kimi-k2.6` 支持，传 `"all"` 启用保留式思考 |
| `signal` | AbortSignal | null | 传入用于取消请求；abort 后抛 `AbortError` |

返回值：

```js
{
  content: "AI 回复内容",
  reasoningContent: "思考过程（启用 thinking 时）",
  model: "使用的模型",
  usage: { prompt_tokens: 10, completion_tokens: 20 },
  raw: { /* 原始响应 */ }
}
```

### getModels()

获取可用模型列表。

### getRemaining()

获取账户余额，**统一返回结构**：

```js
{
  balances: [{ currency: "CNY", amount: 123.45, raw: {...} }],
  raw: { /* 原始响应 */ }
}
```

## 应用侧完整导入

```js
import {
  getAssistant,
  // 仅当应用自己管理 key 时才需要下面这些
  saveKey, removeKey, getApiKeys, onApiKeysChange, testApiKey,
} from "/mz/ai/main.js";
```

## 支持的提供商与模型

| 提供商 | 模型 | 思考模式 | 流式输出 |
|--------|------|----------|----------|
| DeepSeek | `deepseek-flash`, `deepseek-v4-flash`, `deepseek-v4-pro` | ✅ | ✅ |
| Kimi | `kimi-k3`, `kimi-k2.7-code`, `kimi-k2.6`, `kimi-k2.5` | ✅ | ✅ |
| GLM | `glm-5.3`, `glm-5.3-flash`, `glm-4.7` 等（按量付费 Key） | ✅ | ✅ |
| GLM Coding Plan | Coding Plan 订阅 Key（`open.bigmodel.cn/api/coding/paas/v4`） | ✅ | ✅ |
| OpenAI | `gpt-5.6` / `gpt-5.5` / `gpt-5.1` 等（`api.openai.com/v1`，动态拉取为准） | ✅（reasoning_effort） | ✅ |
| Gemini | `gemini-3-flash` / `gemini-3-pro` 等（官方 OpenAI 兼容端点 `generativelanguage.googleapis.com/v1beta/openai`） | ✅（reasoning_effort） | ✅ |
| Anthropic | `claude-opus-5-5` / `claude-sonnet-5-5` / `claude-haiku-4-5`（官方 OpenAI 兼容层 `api.anthropic.com/v1`） | 自适应思考（不透传档位） | ✅ |
| Qwen | `qwen3-max` / `qwen3-plus` / `qwen3-flash` 等（DashScope 兼容模式 `dashscope.aliyuncs.com/compatible-mode/v1`） | ✅（enable_thinking 开关） | ✅ |

> 思考档位按供应商 / 模型不同：`/mz/ai/efforts.js` 的 `effortLevelsFor(provider, model)` 返回可用档位（空数组 = 不可调）、`clampEffort` 把偏好夹取到有效档、`EFFORT_LABELS` 为中文标签——宿主「推理等级」菜单应据此动态生成。

> `kimi-k2-thinking` / `kimi-latest` / `kimi-thinking-preview` 已下线。`deepseek-chat` / `deepseek-reasoner` 旧名已于 2026/07/24 弃用。

---

## key 管理 API（AI Key 管理器 / 代理服务用）

> 以下 API 给"AI Key 管理器应用"或"代理服务端"使用，普通应用通常用不到。

### saveKey(apiKey, provider)

保存 key，返回新保存的 key 对象（含 `id`，可用于 `removeKey` / `getAssistant`）。自动持久化到本地存储（nos storage）并通知订阅者。

- `provider`：`"deepseek"` / `"kimi"` / `"glm"` / `"glm-coding"` / `"openai"` / `"gemini"` / `"anthropic"` / `"qwen"` / `"relay"`（relay 时 apiKey 传服务器签发的完整邀请码）
- `extra`（可选）：附加字段合并进 key 对象，如 `{ serverName: "团队中转" }`（relay 添加时经 `fetchServerInfo(baseUrl)` 拉取服务器命名，`/mz/ai/supplier/relay.js` 导出）

```js
const keyObj = saveKey("sk-xxx", "deepseek");
// keyObj.id 用于后续操作
```

### removeKey(id)

按 id 删除，返回布尔。同样自动持久化 + 通知。

```js
removeKey("abc123"); // true / false
```

### setKeyDisabled(id, disabled)

临时禁用 / 恢复一条 key（数据保留，仅切换状态）。禁用后不参与 `getAssistant()` 随机选取，按 id 获取抛 `key is disabled`。返回布尔，同样自动持久化 + 通知。

```js
setKeyDisabled("abc123", true); // 禁用
setKeyDisabled("abc123", false); // 恢复
```

### getAssistant(id?)

根据 id 获取 Assistant 实例。**同步函数（无 IO）**，调用方可省略 `await`。不传 id 时从**未禁用**的 key 中随机选一个（多 key 负载均衡）。没有可用 key 抛 `no api key available`，id 不存在抛 `key not found`，key 已禁用抛 `key is disabled`。

```js
const assistant = getAssistant("abc123");
const anyAssistant = getAssistant(); // 随机取
```

### getApiKeys()

返回当前所有 key 的**快照**（浅拷贝数组，安全可读）。key 对象结构：

| 字段 | 说明 |
|------|------|
| `id` | 内部唯一 id |
| `provider` | `"deepseek"` / `"kimi"` / `"glm"` / `"glm-coding"` / `"openai"` / `"gemini"` / `"anthropic"` / `"qwen"` / `"relay"` |
| `apiKey` | 原始 key（敏感，UI 展示用 `maskedKey`） |
| `maskedKey` | 脱敏串，如 `sk-abcd...wxyz` |
| `disabled` | 是否被临时禁用（boolean） |
| `createdAt` | ISO 时间戳 |
| `formattedDate` | 本地化时间字符串 |

### onApiKeysChange(callback)

订阅列表变化（`saveKey` / `removeKey` / `setKeyDisabled` 触发），回调收到只读快照数组。返回**取消订阅函数**，组件销毁时务必调用。本模块不依赖框架响应式，UI 层可借此同步视图。

```js
const unsub = onApiKeysChange((keys) => renderKeyList(keys));
// 销毁时
unsub();
```

### updateKey(id, extra)

按 id 合并更新 key 附加字段（持久化 + 通知 `onApiKeysChange`）。旧 relay key 补 `serverName` 用。

### testApiKey(apiKey, provider)

验证 key 是否有效（不写入列表，仅调 `getModels()` 探测）。返回 `{ valid, message }`，**不会抛异常**。

```js
const { valid, message } = await testApiKey("sk-xxx", "kimi");
```

### 完整流程

```js
// 1. 验证
const { valid } = await testApiKey("sk-xxx", "deepseek");
if (!valid) throw new Error("key 无效");
// 2. 保存
saveKey("sk-xxx", "deepseek");
// 3. 订阅
const unsub = onApiKeysChange((keys) => renderKeyList(keys));
// 4. 对话
const assistant = getAssistant();
const result = await assistant.chat({
  model: "deepseek-flash",
  messages: [{ role: "user", content: "你好" }],
});
// 5. 清理
unsub();
```

## 思考模式

### DeepSeek

默认开启思考模式，可 `thinking: false` 关闭。强度通过 `reasoningEffort` 控制：官方按 `low` / `high` / `max` 三档执行，请求还可传 `minimal` / `medium` / `xhigh` / `ultra`，由官方自动映射（minimal/low→low，medium/high/xhigh→high，max/ultra→max）。本库原样透传，不做本地映射。

### Kimi（按模型区分，最易出错）

| 模型 | thinking | reasoningEffort | thinkingKeep |
|------|----------|-----------------|--------------|
| `kimi-k3` | ❌ 不支持 | ✅ `low`/`high`/`max` | ❌ |
| `kimi-k2.7-code` | 无效（始终思考） | ❌ | ❌ |
| `kimi-k2.6` | ✅ 默认 true | ❌ | ✅ `"all"` |
| `kimi-k2.5` | ✅ 默认 true | ❌ | ❌ |

```js
// ✅ kimi-k3
await assistant.chat({
  model: "kimi-k3",
  messages: [...],
  reasoningEffort: "max",
});

// ✅ kimi-k2.6
await assistant.chat({
  model: "kimi-k2.6",
  messages: [...],
  thinking: true,
  thinkingKeep: "all",
});

// ❌ 对 kimi-k3 传 thinking 会报错
```

### GLM（按模型版本区分，注意 5.3 行为变化）

| 模型版本 | 控制方式 | 说明 |
|----------|----------|------|
| GLM-4.x（`glm-4.7` 等） | `thinking` 开关 | 4.7 系默认开启思考，`thinking: false` 显式关闭；`reasoningEffort` 被忽略 |
| GLM-5.3+（`glm-5.3` / `glm-5.3-flash`，模型名 `glm-5` 开头） | `reasoningEffort` 三档 | 思考**不可关闭**、不发 `thinking` 参数；档位 `low`/`high`/`max` |

GLM-5.3+ 的档位取值规则（`glm.js` 内实现）：

- 显式传 `reasoningEffort`：原样透传，优先级最高
- 未传档位：取 `"low"`（与 DeepSeek / Kimi 默认一致）
- `thinking: false`（默认）且未传档位：取 `"low"`（官方迁移路径：原「关闭思考」场景改用最低档）

```js
// GLM-5.3-flash 深度思考
await assistant.chat({
  model: "glm-5.3-flash",
  messages: [...],
  thinking: true,
  reasoningEffort: "max",
});
```

## 流式输出

```js
await assistant.chat({
  messages: [{ role: "user", content: "写一首诗" }],
  stream: true,
  onStream: (data) => {
    console.log(data.content);          // 累计内容
    console.log(data.delta);            // 本次增量
    console.log(data.deltaReasoning);   // 思考增量
    console.log(data.done);             // 是否完成
  },
});
```

## 取消请求（AbortSignal）

```js
const controller = new AbortController();
try {
  await assistant.chat({
    messages: [...],
    stream: true,
    signal: controller.signal,
    onStream: (data) => console.log(data.delta),
  });
} catch (err) {
  if (err.name === "AbortError") {
    console.log("已取消"); // 底层连接和流读取立即释放
  } else {
    throw err;
  }
}
```

## 作为代理服务端的注意点

`ai/` 模块**不依赖 noneos-core**，可独立用于任何 JS 环境。当作为代理（用我方 key 替对方提问、转发流回对方）使用时：

- ✅ 已内置 `signal` 支持，对方断开 → `controller.abort()` → 立刻释放配额
- ✅ `onStream` 回调可桥接到 `remoteUser.sendToService` 转发分片
- ⚠️ 代理服务端的 key 池管理（限流/熔断/轮询）**不要塞进 `main.js`**，应另起 `ai-proxy/` 模块
- ⚠️ 不要把 noneos-core 依赖引入 `ai/`，会破坏其可复用性

## 测试

使用 sibyl-test，supplier 层测试位于 `mz/ai/test/ai-supplier-sb.html`：

```bash
# 填入真实 key（已 gitignore）
# test-api-keys.json: { "deepseek": "sk-...", "kimi": "sk-..." }

npx sb-test -f ai/test/ai-supplier-sb.html --browsers chrome
```

覆盖范围：main.js 全部导出（离线）、AbortSignal 取消、DeepSeek/Kimi 对话/思考/流式、Kimi 各模型思考参数分支构建、GLM 按模型版本思考参数分支构建（不依赖真实 key）、错误处理。

## 项目结构

```
ai/
├── main.js                       # API Key 管理 + Assistant 工厂
├── supplier/
│   ├── assistant.js              # Assistant 基类（handleStreamResponse / _buildError）
│   ├── deepseek.js               # DeepSeek 实现
│   ├── kimi.js                   # Kimi 实现
│   ├── glm.js                    # GLM 实现（含 Coding Plan 子类）
│   └── relay.js                  # ai-relay 转发服务器实现（邀请码即 apiKey，decodeInvite 解出服务器地址+bearkey；自动完成 NoneOS 用户激活绑定并在请求带 X-Relay-Auth 签名头）
├── chain/                        # Agent 封装（见 ai-chain.md）
├── test/
│   ├── ai-supplier-sb.html       # supplier 层测试（sibyl-test）
│   └── ai-chain-sb.html          # Agent 循环测试（真实 deepseek-v4-flash）

根目录 test-api-keys.json      # 本地测试 key（gitignore）
```
